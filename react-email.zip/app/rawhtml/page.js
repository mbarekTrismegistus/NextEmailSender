import RawHtmlSender from "./rawHtml";

export default function page() {

  return (
    <RawHtmlSender/> 
  )
}
